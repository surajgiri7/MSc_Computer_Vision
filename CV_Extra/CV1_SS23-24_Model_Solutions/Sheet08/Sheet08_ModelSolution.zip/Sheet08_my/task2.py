import numpy as np
import utils

# ======================= PPCA =======================
def ppca(covariance, preservation_ratio=0.9):
    U, s, VT = np.linalg.svd(covariance, full_matrices=True)
    eigenvectors = U
    eigenvalues = s

    idxs = np.argsort(s)[::-1]
    eigenvectors = U[idxs, :]
    eigenvalues = s[idxs]


    eigval_sum = np.sum(eigenvalues)
    cum = 0
    for i in range(len(eigenvalues)):
        cum += eigenvalues[i]
        if cum / eigval_sum >= 0.9:
            break

    print("We select %d PCs" % (i + 1))

    selected_eigenvalues = eigenvalues[:(i+1)]
    selected_pcs = eigenvectors[:, :(i+1)]
    selected_pcs = selected_pcs / np.sqrt(selected_eigenvalues[None, :])  # ensures that variance along each component is equal to one
   

    # Probabilistic version
    sigma = np.sum(eigenvalues[(i+1):]) / (len(eigenvalues) - (i + 1)) 
    noise = (eigenvalues[:(i+1)] - sigma) ** 0.5 
    selected_pcs = selected_pcs @ np.diag(noise)
    return selected_pcs.T, selected_eigenvalues, sigma




# ======================= Covariance =======================

def create_covariance_matrix(kpts, mean_shape):
    aligned_kpts = kpts - mean_shape[np.newaxis, :]
    covariance = np.dot(aligned_kpts.transpose(), aligned_kpts)

    return covariance





# ======================= Visualization =======================

def visualize_impact_of_pcs(mean, pcs, pc_weights):
    for pc_idx in range(pc_weights.shape[0]):
        ax = utils.visualize_hands(mean[np.newaxis, :].reshape([1, -1, 2]),
                                   title="Variation of PC %d" % (pc_idx + 1),
                                   clear=True, delay=0.1)
        for itr in range(5):
            weights = np.linspace(-0.3, 0.3, 7)

            for weight in weights:
                tmp_shape = mean.copy()
                w = weight * np.sqrt(pc_weights[pc_idx])

                tmp_shape += pcs[pc_idx, :] * w
                ax = utils.visualize_hands(tmp_shape[np.newaxis, :].reshape([1, -1, 2]),
                                            title="Variation of PC %d" % (pc_idx + 1),
                                            clear=True, delay=0.1, ax=ax)





# ======================= Training =======================
def train_statistical_shape_model(kpts):

    # Mean Shape
    mean_shape = np.mean(kpts, axis=0)
    shapes_ax = utils.visualize_hands(mean_shape[np.newaxis, :].reshape([1, -1, 2]),
                                      "Initial Mean Shape", 0.1)

    # COVAR
    covariance = create_covariance_matrix(kpts, mean_shape)

    # PCA
    pcs, pc_weights, sigma = ppca(covariance)

    # VIS
    visualize_impact_of_pcs(mean_shape, pcs, pc_weights)

    return mean_shape, pcs, pc_weights, sigma




# ======================= Reconstruct =======================
def reconstruct_test_shape(kpts, mean, pcs, pc_weight, sigma):

    # Align test shape
    aligned_kpts = kpts - mean[None, :]
    c = np.dot(pcs, aligned_kpts[0])
    weighted_pcs = c[:, None] * pcs 
    reconstruction = mean + np.sum(weighted_pcs, axis=0) #+ np.random.normal(scale=np.sqrt(sigma), size=kpts.shape)



    # calculate reconstruction error
    error = np.sqrt(np.mean((kpts - reconstruction) ** 2))
    print("RMS:", error)

    # Visualize
    utils.visualize_hands(kpts[np.newaxis, :].reshape([1, -1, 2]),
                                title="Original Shape")

    utils.visualize_hands(reconstruction[np.newaxis, :].reshape([1, -1, 2]),
                                title="Reconstructed Shape")
