import numpy as np
import utils



# ========================== Mean =============================
def calculate_mean_shape(kpts):
    """
        calculates mean shape and fix it to unit variance
        kpts: num_samples x num_points x 2
    """

    mean_shape = np.mean(kpts, axis=0)
    mean_point = np.mean(mean_shape, axis=0)

    # calculate the variance
    var = np.sum(mean_point ** 2)

    # scale mean to unit variance
    scale = np.sqrt(1 / var)
    mean_shape *= scale

    return mean_shape


# Solve for affine transformation from each shape to the mean shape
def affine_transf(kpts, reference_mean):
    # B x N x 2
    # 1 x N x 2
    b, n = kpts.shape[0], kpts.shape[1]
    sol = reference_mean.flatten()  # 1 x N * 2
  
    # Fill in the matrix
    A = np.zeros((b, n, 2, 6))
    A[..., 0, 0] = kpts[..., 0]
    A[..., 0, 1] = kpts[..., 1]
    A[..., 0, 2] = 1

    A[..., 1, -1] = 1
    A[..., 1, -2] = kpts[..., 1]
    A[..., 1, -3] = kpts[..., 0]
  
    A = np.reshape(A, (b, n * 2, 6))
    pi_A = np.linalg.pinv(A)
    affine_transf = np.dot(pi_A, sol) 
    rot_scale = np.zeros((b, 2, 2))
    transl = np.zeros((b, 2))

    rot_scale[:, 0, 0] = affine_transf[:, 0]
    rot_scale[:, 0, 1] = affine_transf[:, 1]
    rot_scale[:, 1, 0] = affine_transf[:, 3]
    rot_scale[:, 1, 1] = affine_transf[:, 4]
    
    transl[:, 0] = affine_transf[:, 2]
    transl[:, 1] = affine_transf[:, 5]

    return rot_scale, transl




# ====================== Main Step ===========================
def procrustres_analysis_step(kpts, reference_mean):
    rot, transl = affine_transf(kpts, reference_mean)
    rotated_kpts = np.asarray([np.dot(rot[i], kpts[i].T).T for i in range(rot.shape[0])])
    transl_kpts = rotated_kpts + transl[:, None, :]
    return transl_kpts



# =========================== Error ====================================

def compute_avg_error(kpts, mean_shape):

    squared_diff = (kpts - mean_shape[None, :, :]) ** 2

    rmse = np.sqrt(np.mean(squared_diff))

    return rmse




# ============================ Procrustres ===============================

def procrustres_analysis(kpts, max_iter=int(1e3), min_error=1e-2):

    aligned_kpts = kpts.copy()

    for iter in range(max_iter):

        reference_mean = calculate_mean_shape(aligned_kpts)

        # align shapes to mean shape
        aligned_kpts = procrustres_analysis_step(aligned_kpts, reference_mean)

        # calculate new reference mean
        reference_mean = calculate_mean_shape(aligned_kpts)

        # calculate alignment error
        rmse = compute_avg_error(aligned_kpts, reference_mean)

        print("(%d) RMSE: %f" % (iter + 1, rmse))

        if rmse <= min_error:
            break

    # visualize
    utils.visualize_hands(aligned_kpts, "aligned keypoints", 0.1)

    # visualize mean shape
    utils.visualize_hands(reference_mean[np.newaxis, :, :], "reference mean")

    return aligned_kpts
